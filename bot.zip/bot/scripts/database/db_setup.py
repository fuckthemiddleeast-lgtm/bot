"""
db_setup.py — راه‌اندازی اولیه MySQL و ساخت جداول و داده‌های پیش‌فرض
پیش‌نیاز: MySQL نصب و در حال اجرا باشد

اجرا: python3 db_setup.py
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import pymysql
import json

# ═══════════════════════════════════════════════════════════════
# ⚙️  تنظیمات دیتابیس — برای هر شرکت این مقادیر را تغییر دهید
# ═══════════════════════════════════════════════════════════════
MYSQL_HOST     = "localhost"           # آدرس سرور MySQL
MYSQL_PORT     = 3306                  # پورت MySQL
MYSQL_USER     = "root"                # نام کاربری MySQL
MYSQL_PASSWORD = "insurance_Sina_BimeBot2026"           # 🔑 رمز عبور MySQL — تغییر دهید
MYSQL_DB       = "insurance_bot_db"    # 🔑 نام دیتابیس — تغییر دهید
# ═══════════════════════════════════════════════════════════════

def create_database():
    """ساخت دیتابیس اگر وجود نداشته باشد"""
    print(f"🔌 اتصال به MySQL سرور {MYSQL_HOST}...")
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        charset='utf8mb4'
    )
    cursor = conn.cursor()
    cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{MYSQL_DB}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
    conn.commit()
    cursor.close()
    conn.close()
    print(f"✅ دیتابیس `{MYSQL_DB}` ساخته/بررسی شد.")

def create_tables():
    """ساخت جداول اگر وجود نداشته باشند"""
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    # جدول بیمه‌ها
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS insurances (
            id INT AUTO_INCREMENT PRIMARY KEY,
            category VARCHAR(255),
            name VARCHAR(255),
            documents TEXT,
            is_active TINYINT DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')

    # جدول اقساط
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS installments (
            national_id VARCHAR(10) PRIMARY KEY,
            phone VARCHAR(20),
            total_installments INT DEFAULT 0,
            amount_per_installment INT DEFAULT 0,
            distinct_installment TEXT,
            total_paid_so_far INT DEFAULT 0,
            next_due_date VARCHAR(20),
            chat_id BIGINT DEFAULT NULL,
            reminder_48h TINYINT DEFAULT 0,
            reminder_24h TINYINT DEFAULT 0,
            reminder_due TINYINT DEFAULT 0,
            reminder_overdue TINYINT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')

    # جدول تاریخچه پرداخت‌ها (برای گزارش فروش)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            national_id VARCHAR(10),
            amount INT DEFAULT 0,
            pay_type VARCHAR(50),
            paid_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')

    # جدول تنظیمات سیستم
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS system_settings (
            setting_key VARCHAR(100) PRIMARY KEY,
            setting_value TINYINT DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')

    conn.commit()
    print("✅ جداول ساخته/بررسی شدند.")
    cursor.close()
    conn.close()

def create_payment_invoices_table():
    """ساخت جدول فاکتورهای پرداخت کارت‌به‌کارت اگر وجود نداشته باشد"""
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    # جدول فاکتورهای پرداخت کارت‌به‌کارت
    #
    # ATOMICITY NOTE: The UNIQUE KEY on `unique_amount` alone (not composite
    # with `status`) is intentional. This ensures no two invoices — regardless
    # of status — ever share the same unique_amount. The _generate_unique_offset
    # algorithm relies on MySQL raising errno 1062 (Duplicate Entry) when an
    # INSERT would violate this constraint. On conflict, the application retries
    # with a new random offset (up to 200 times). This avoids race conditions
    # without application-level locks: the database constraint itself is the
    # atomic guard. A SELECT-then-INSERT pattern would have a TOCTOU race window
    # between the check and the insert; the INSERT-and-catch pattern does not.
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payment_invoices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            national_id VARCHAR(10) NOT NULL,
            chat_id BIGINT NOT NULL,
            invoice_amount INT NOT NULL COMMENT 'Base installment amount in tomans',
            unique_amount INT NOT NULL COMMENT 'invoice_amount + offset_value',
            offset_value INT NOT NULL COMMENT 'Random offset (-100 to +100)',
            status ENUM('pending', 'receipt_submitted', 'auto_confirmed', 'admin_confirmed', 'rejected') DEFAULT 'pending',
            receipt_file_id TEXT DEFAULT NULL COMMENT 'Telegram file_id of receipt photo',
            admin_message_id BIGINT DEFAULT NULL COMMENT 'Message ID in admin chat',
            log_message_id BIGINT DEFAULT NULL COMMENT 'Message ID in log channel',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            confirmed_at DATETIME DEFAULT NULL,
            INDEX idx_national_id (national_id),
            INDEX idx_chat_id (chat_id),
            INDEX idx_status (status),
            INDEX idx_unique_amount (unique_amount),
            UNIQUE KEY unique_pending_amount (unique_amount)
                COMMENT 'Atomicity guard: no two invoices share unique_amount; INSERT fails with errno 1062 on conflict, triggering retry in application code'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')

    conn.commit()
    print("✅ جدول payment_invoices ساخته/بررسی شد.")
    cursor.close()
    conn.close()


def migrate_payment_invoices_table():
    """Migration امن برای جدول payment_invoices:
    - اگر جدول وجود نداشته باشد، ایجاد می‌شود.
    - اگر وجود داشته باشد، ستون‌های جدید اضافه می‌شوند (در صورت نیاز).
    این تابع idempotent است و می‌تواند چندین بار روی دیتابیس موجود اجرا شود.
    """
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    # بررسی وجود جدول
    cursor.execute("SHOW TABLES LIKE 'payment_invoices'")
    table_exists = cursor.fetchone() is not None

    if not table_exists:
        print("  📋 جدول payment_invoices وجود ندارد، در حال ایجاد...")
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payment_invoices (
                id INT AUTO_INCREMENT PRIMARY KEY,
                national_id VARCHAR(10) NOT NULL,
                chat_id BIGINT NOT NULL,
                invoice_amount INT NOT NULL COMMENT 'Base installment amount in tomans',
                unique_amount INT NOT NULL COMMENT 'invoice_amount + offset_value',
                offset_value INT NOT NULL COMMENT 'Random offset (-100 to +100)',
                status ENUM('pending', 'receipt_submitted', 'auto_confirmed', 'admin_confirmed', 'rejected') DEFAULT 'pending',
                receipt_file_id TEXT DEFAULT NULL COMMENT 'Telegram file_id of receipt photo',
                admin_message_id BIGINT DEFAULT NULL COMMENT 'Message ID in admin chat',
                log_message_id BIGINT DEFAULT NULL COMMENT 'Message ID in log channel',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                confirmed_at DATETIME DEFAULT NULL,
                INDEX idx_national_id (national_id),
                INDEX idx_chat_id (chat_id),
                INDEX idx_status (status),
                INDEX idx_unique_amount (unique_amount),
                UNIQUE KEY unique_pending_amount (unique_amount)
                    COMMENT 'Atomicity guard: no two invoices share unique_amount; INSERT fails with errno 1062 on conflict, triggering retry in application code'
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        conn.commit()
        print("  ✅ جدول payment_invoices با موفقیت ساخته شد.")
    else:
        print("  ℹ️ جدول payment_invoices از قبل موجود است. بررسی ستون‌های جدید...")

        # لیست ستون‌های فعلی جدول
        cursor.execute("SHOW COLUMNS FROM payment_invoices")
        existing_cols = {row[0] for row in cursor.fetchall()}

        # ستون‌هایی که باید در جدول وجود داشته باشند
        required_columns = {
            "id":               "ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY",
            "national_id":      "ADD COLUMN national_id VARCHAR(10) NOT NULL DEFAULT ''",
            "chat_id":          "ADD COLUMN chat_id BIGINT NOT NULL DEFAULT 0",
            "invoice_amount":   "ADD COLUMN invoice_amount INT NOT NULL DEFAULT 0",
            "unique_amount":    "ADD COLUMN unique_amount INT NOT NULL DEFAULT 0",
            "offset_value":     "ADD COLUMN offset_value INT NOT NULL DEFAULT 0",
            "status":           "ADD COLUMN status ENUM('pending', 'receipt_submitted', 'auto_confirmed', 'admin_confirmed', 'rejected') DEFAULT 'pending'",
            "receipt_file_id":  "ADD COLUMN receipt_file_id TEXT DEFAULT NULL",
            "admin_message_id": "ADD COLUMN admin_message_id BIGINT DEFAULT NULL",
            "log_message_id":   "ADD COLUMN log_message_id BIGINT DEFAULT NULL",
            "created_at":       "ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP",
            "confirmed_at":     "ADD COLUMN confirmed_at DATETIME DEFAULT NULL",
        }

        added = 0
        for col_name, col_def in required_columns.items():
            if col_name not in existing_cols:
                cursor.execute(f"ALTER TABLE payment_invoices {col_def}")
                added += 1
                print(f"    ➕ ستون {col_name} اضافه شد.")

        conn.commit()
        if added:
            print(f"  ✅ Migration payment_invoices: {added} ستون جدید اضافه شد.")
        else:
            print("  ✅ Migration payment_invoices: همه ستون‌ها از قبل موجود بودند.")

    cursor.close()
    conn.close()


def migrate_installments_columns():
    """افزودن ستون‌های یادآوری به جدول installments در صورت عدم وجود (Migration امن)"""
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    # لیست ستون‌های فعلی جدول
    cursor.execute("SHOW COLUMNS FROM installments")
    existing_cols = {row[0] for row in cursor.fetchall()}

    new_columns = {
        "chat_id": "ADD COLUMN chat_id BIGINT DEFAULT NULL",
        "reminder_48h": "ADD COLUMN reminder_48h TINYINT DEFAULT 0",
        "reminder_24h": "ADD COLUMN reminder_24h TINYINT DEFAULT 0",
        "reminder_due": "ADD COLUMN reminder_due TINYINT DEFAULT 0",
        "reminder_overdue": "ADD COLUMN reminder_overdue TINYINT DEFAULT 0",
        "created_at": "ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP",
    }

    added = 0
    for col_name, col_def in new_columns.items():
        if col_name not in existing_cols:
            cursor.execute(f"ALTER TABLE installments {col_def}")
            added += 1
            print(f"  ➕ ستون {col_name} اضافه شد.")

    conn.commit()
    cursor.close()
    conn.close()
    if added:
        print(f"✅ Migration: {added} ستون جدید اضافه شد.")
    else:
        print("✅ Migration: همه ستون‌های یادآوری از قبل موجود بودند.")

def insert_default_data():
    """درج داده‌های پیش‌فرض"""
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    # داده‌های پیش‌فرض تنظیمات سیستم
    default_settings = [
        ('installments_enabled', 1),
        ('auth_by_national_id', 1),
        ('auth_by_phone', 1),
    ]
    cursor.executemany(
        "INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES (%s, %s)",
        default_settings
    )
    print(f"✅ {len(default_settings)} تنظیم پیش‌فرض درج شد.")

    # بررسی اینکه آیا بیمه‌ای از قبل وجود دارد یا نه
    cursor.execute("SELECT COUNT(*) FROM insurances")
    if cursor.fetchone()[0] > 0:
        print("ℹ️ بیمه‌ها قبلاً در دیتابیس وجود دارند. از درج داده‌های پیش‌فرض صرف‌نظر شد.")
        conn.close()
        return

    # داده‌های پیش‌فرض بیمه‌ها (دقیقاً همان داده‌های init_db در بوت)
    default_data = [
        ("بیمه خودرو", "شخص ثالث", json.dumps(["عکس روی کارت خودرو", "عکس پشت کارت خودرو", "📷✍️ تصویر گواهینامه یا کارت ملی (در صورت عدم دسترسی، کد ملی و تاریخ تولد خود را تایپ کنید)"])),
        ("بیمه خودرو", "بدنه خودرو", json.dumps(["عکس کارت خودرو", "📷✍️ تصویر گواهینامه یا کارت ملی (در صورت عدم دسترسی، کد ملی و تاریخ تولد خود را تایپ کنید)", "عکس سند یا برگ سبز", "عکس از سمت جلو خودرو", "عکس از سمت عقب خودرو", "عکس از سمت راست خودرو", "عکس از سمت چپ خودرو"])),
        ("بیمه اشخاص", "تکمیلی درمان", json.dumps(["عکس کارت ملی", "عکس صفحه اول شناسنامه", "✍️ نام و کد ملی افراد تحت تکفل (لطفاً به صورت متن یک‌جا ارسال کنید)"])),
        ("بیمه اشخاص", "عمر و سرمایه‌گذاری", json.dumps(["عکس کارت ملی", "عکس صفحه اول شناسنامه", "عکس فرم تکمیل شده سلامت"])),
        ("مستقیم", "بیمه سرمایه‌گذاری از طریق خرید طلا", json.dumps([])),
        ("بیمه دیجیتال", "بیمه موبایل و لپ‌تاپ", json.dumps(["📷✍️ مارک و مدل دستگاه (می‌توانید بنویسید یا عکس برند/جعبه آن را بفرستید)", "✍️ قیمت تقریبی دستگاه به تومان (لطفاً به صورت متن ارسال کنید)"])),
        ("بیمه آتش‌سوزی مسکونی و زلزله", "آتش‌سوزی مسکونی و زلزله", json.dumps(["✍️ نوع ملک شما چیست؟ (ویلایی یا آپارتمانی؟)", "✍️ لطفاً ارزش ساختمان و ارزش اثاثیه محل مورد بیمه را به تومان وارد کنید:"])),
        ("بیمه آتش‌سوزی مسکونی و زلزله", "آتش‌سوزی تجاری و زلزله", json.dumps(["✍️ آیا ملک تجاری شما شیشه سکوریت دارد؟ (بله یا خیر؟)", "✍️ لطفاً ارزش شیشه سکوریت (در صورت وجود) و میزان موجودی کل اجناس مغازه را به تومان وارد کنید:"])),
        ("بیمه مسئولیت", "مسئولیت ساختمانی", json.dumps(["✍️ لطفاً متراژ ساخت پروژه خود را به همراه اضافه بنا یا خلافی احتمالی وارد کنید:", "✍️ در حال حاضر پروژه در چه مرحله‌ای از ساخت می‌باشد ؟", "📷✍️ در صورت امکان، تصویر پروانه ساختمان را ارسال کنید (یا مشخصات آن را بنویسید):"])),
        ("بیمه مسئولیت", "مسئولیت کارفرمایی تجاری", json.dumps(["✍️ لطفاً شغل دقیق مورد بیمه را وارد کنید (مثال: نجاری، سوپرمارکت و...):", "✍️ تعداد دقیق کارکنان خود را وارد کنید:"])),
    ]
    cursor.executemany(
        "INSERT INTO insurances (category, name, documents) VALUES (%s, %s, %s)",
        default_data
    )
    conn.commit()
    print(f"✅ {len(default_data)} بیمه پیش‌فرض درج شد.")
    cursor.close()
    conn.close()


def create_payment_feedback_table():
    """ساخت جدول بازخورد کاربران برای سیستم پرداخت کارت‌به‌کارت"""
    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payment_feedback (
            id INT AUTO_INCREMENT PRIMARY KEY,
            chat_id BIGINT NOT NULL COMMENT 'شناسه کاربر',
            invoice_id INT DEFAULT NULL COMMENT 'شناسه فاکتور مرتبط (در صورت وجود)',
            rating TINYINT NOT NULL COMMENT 'امتیاز کاربر (1 تا 5)',
            feedback_text TEXT DEFAULT NULL COMMENT 'متن بازخورد اختیاری',
            submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_chat_id (chat_id),
            INDEX idx_rating (rating),
            INDEX idx_submitted_at (submitted_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ''')

    conn.commit()
    print("✅ جدول payment_feedback ساخته/بررسی شد.")
    cursor.close()
    conn.close()


def main():
    print("=" * 50)
    print("🔧 راه‌اندازی دیتابیس MySQL برای ربات بیمه")
    print("=" * 50)
    create_database()
    create_tables()
    create_payment_invoices_table()
    create_payment_feedback_table()
    print("🔄 بررسی migration جداول...")
    migrate_payment_invoices_table()
    migrate_installments_columns()
    insert_default_data()
    print("=" * 50)
    print("🎉 راه‌اندازی دیتابیس با موفقیت کامل شد!")
    print("=" * 50)


if __name__ == "__main__":
    main()
