"""
excel_to_db.py — ابزار مستقل تبدیل فایل اکسل اقساط به دیتابیس MySQL
پیش‌نیاز: MySQL نصب و دیتابیس با db_setup.py ساخته شده باشد

اجرا: python3 excel_to_db.py
"""

import os
import json
import re
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import logging
import pandas as pd
import pymysql

# ═══════════════════════════════════════════════════════════════
# ⚙️  تنظیمات دیتابیس — برای هر شرکت این مقادیر را تغییر دهید
# ═══════════════════════════════════════════════════════════════
MYSQL_HOST     = "localhost"           # آدرس سرور MySQL
MYSQL_PORT     = 3306                  # پورت MySQL
MYSQL_USER     = "root"                # نام کاربری MySQL
MYSQL_PASSWORD = "insurance_Sina_BimeBot2026"           # 🔑 رمز عبور MySQL — تغییر دهید
MYSQL_DB       = "insurance_bot_db"    # 🔑 نام دیتابیس — تغییر دهید
# ═══════════════════════════════════════════════════════════════

logging.basicConfig(level=logging.INFO)

# مسیر فایل اکسل نسبت به ریشه پروژه
EXCEL_FILE_NAME = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'installments.xlsx')


def convert_persian_numbers(text):
    """تبدیل اعداد فارسی/عربی به انگلیسی"""
    if not text:
        return text
    text = str(text)
    persian_to_eng = {
        '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
        '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
        '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
        '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9'
    }
    for p, e in persian_to_eng.items():
        text = text.replace(p, e)
    return text


def normalize_phone_db(phone_str):
    """نرمال‌سازی شماره تماس به فرمت بین‌المللی 98..."""
    phone_str = convert_persian_numbers(phone_str)
    phone = "".join(filter(str.isdigit, str(phone_str)))
    if phone.startswith("09") and len(phone) == 11:
        return "98" + phone[1:]
    elif phone.startswith("989") and len(phone) == 12:
        return phone
    elif phone.startswith("9") and len(phone) == 10:
        return "98" + phone
    return phone


def validate_national_id(nid_str):
    """اعتبارسنجی کد ملی (۱۰ رقم)"""
    nid_str = convert_persian_numbers(nid_str)
    nid = "".join(filter(str.isdigit, str(nid_str)))
    if len(nid) == 10:
        return nid
    return None


def jalali_to_gregorian(jy, jm, jd):
    """تبدیل تاریخ شمسی به میلادی"""
    jy -= 979
    g_day_no = 365 * jy + (jy // 33) * 8 + ((jy % 33) + 3) // 4
    for i in range(jm - 1):
        if i < 6:
            g_day_no += 31
        else:
            g_day_no += 30
    g_day_no += jd - 1
    g_day_no += 79

    gy = 1600 + 400 * (g_day_no // 146097)
    g_day_no %= 146097

    leap = 1
    if g_day_no >= 36525:
        g_day_no -= 1
        gy += 100 * (g_day_no // 36524)
        g_day_no %= 36524
        if g_day_no >= 365:
            g_day_no += 1
        else:
            leap = 0

    gy += 4 * (g_day_no // 1461)
    g_day_no %= 1461

    if g_day_no >= 366:
        leap = 0
        g_day_no -= 1
        gy += g_day_no // 365
        g_day_no %= 365

    for i, m_days in enumerate([31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], 1):
        if g_day_no < m_days:
            return f"{gy}-{i:02d}-{(g_day_no + 1):02d}"
        g_day_no -= m_days
    return f"{gy}-01-01"


def parse_and_convert_shamsi(shamsi_str):
    """تبدیل رشته تاریخ شمسی به میلادی"""
    shamsi_str = convert_persian_numbers(shamsi_str)
    shamsi_str = str(shamsi_str).replace('/', '-').replace('_', '-').strip()
    parts = [int(p) for p in shamsi_str.split('-') if p.isdigit()]
    if len(parts) == 3:
        return jalali_to_gregorian(parts[0], parts[1], parts[2])
    raise ValueError(f"فرمت تاریخ نامعتبر: {shamsi_str}")


def import_excel_to_mysql():
    """خواندن فایل اکسل و درج در MySQL"""
    if not os.path.exists(EXCEL_FILE_NAME):
        logging.error(f"❌ فایل {EXCEL_FILE_NAME} یافت نشد!")
        return

    df = pd.read_excel(EXCEL_FILE_NAME)
    df.columns = [str(col).strip() for col in df.columns]
    required_cols = ['کد ملی', 'تعداد اقساط', 'مبلغ هر قسط', 'تاریخ قسط بعدی']
    if not all(col in df.columns for col in required_cols):
        logging.error(f"❌ ستون‌های ضروری در فایل اکسل یافت نشد. ستون‌ها: {list(df.columns)}")
        return

    conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset='utf8mb4'
    )
    cursor = conn.cursor()

    imported = 0
    skipped = 0

    for _, row in df.iterrows():
        if pd.isna(row['کد ملی']):
            skipped += 1
            continue

        nat_id = validate_national_id(str(row['کد ملی']).strip().split('.')[0])
        if not nat_id:
            skipped += 1
            continue

        raw_phone = str(row['شماره تماس']).strip().split('.')[0] if 'شماره تماس' in df.columns and not pd.isna(row['شماره تماس']) else "نامشخص"
        phone = normalize_phone_db(raw_phone)

        total_ins = int(row['تعداد اقساط']) if not pd.isna(row['تعداد اقساط']) else 0
        amount = int(row['مبلغ هر قسط']) if not pd.isna(row['مبلغ هر قسط']) else 0
        distinct = str(row['قسط متمایز']).strip() if 'قسط متمایز' in df.columns and not pd.isna(row['قسط متمایز']) else "ندارد"

        if 'مبلغ پرداخت شده تا این لحظه' in df.columns and not pd.isna(row['مبلغ پرداخت شده تا این لحظه']):
            paid_so_far = int(row['مبلغ پرداخت شده تا این لحظه'])
        elif 'اقساط پرداخت شده' in df.columns and not pd.isna(row['اقساط پرداخت شده']):
            paid_so_far = int(row['اقساط پرداخت شده']) * amount
        else:
            paid_so_far = 0

        shamsi_date = str(row['تاریخ قسط بعدی']).strip().split(' ')[0]
        try:
            due_date = parse_and_convert_shamsi(shamsi_date)
        except ValueError:
            due_date = shamsi_date

        cursor.execute(
            """INSERT INTO installments (national_id, phone, total_installments, amount_per_installment, distinct_installment, total_paid_so_far, next_due_date)
               VALUES (%s, %s, %s, %s, %s, %s, %s)
               ON DUPLICATE KEY UPDATE
               phone = VALUES(phone),
               total_installments = VALUES(total_installments),
               amount_per_installment = VALUES(amount_per_installment),
               distinct_installment = VALUES(distinct_installment),
               total_paid_so_far = VALUES(total_paid_so_far),
               next_due_date = VALUES(next_due_date)""",
            (nat_id, phone, total_ins, amount, distinct, paid_so_far, due_date)
        )
        imported += 1

    conn.commit()
    cursor.close()
    conn.close()

    print(f"✅ ایمپورت تمام شد: {imported} ردیف وارد شد, {skipped} ردیف رد شد.")


if __name__ == "__main__":
    print("=" * 50)
    print("📊 ایمپورت فایل اکسل اقساط به MySQL")
    print("=" * 50)
    import_excel_to_mysql()
    print("=" * 50)
