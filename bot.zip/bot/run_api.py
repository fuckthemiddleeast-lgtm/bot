#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import uvicorn
from src.api.server import app
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
